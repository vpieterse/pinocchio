from django.contrib import admin

from .models import User

class UserAdmin(admin.ModelAdmin):
	fieldsets = [
        ('User Information', {'fields': ('user_title', 'user_initials', 'user_firstName',
        	'user_surname', 'user_studentNumber', 'user_status', 'user_cellNumber',
        	'user_email', 'user_password')}),
        ('Date Information', 	{'fields': ['user_pub_date'], 'classes':['collapse']}),
    ]

admin.site.register(User, UserAdmin)