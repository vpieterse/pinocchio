from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.views import generic

from .models import User

class IndexView(generic.ListView):
    template_name = 'userAdmin/userAdmin.html'
    context_object_name = 'user_list'

    def get_queryset(self):
        return User.objects.order_by('-user_studentNumber')[:5]
