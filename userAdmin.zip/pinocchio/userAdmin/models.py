import datetime

from django.db import models
from django.utils import timezone

class User(models.Model):
	user_title = models.CharField(max_length = 5)
	user_initials = models.CharField(max_length = 5)
	user_firstName = models.CharField(max_length = 50)
	user_surname = models.CharField(max_length = 50)
	user_studentNumber = models.CharField(max_length = 8)
	user_status = models.CharField(max_length = 1)
	user_cellNumber = models.CharField(max_length = 10)
	user_email = models.CharField(max_length = 100)
	user_password = models.CharField(max_length = 30)
	user_pub_date = models.DateTimeField('date published')
	def __str__(self):
		return self.user_studentNumber + " - " + self.user_title + " " + self.user_initials + " " + self.user_surname