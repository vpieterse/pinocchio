# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='User',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, primary_key=True, verbose_name='ID')),
                ('user_title', models.CharField(max_length=5)),
                ('user_initials', models.CharField(max_length=5)),
                ('user_firstName', models.CharField(max_length=50)),
                ('user_surname', models.CharField(max_length=50)),
                ('user_studentNumber', models.CharField(max_length=8)),
                ('user_status', models.CharField(max_length=1)),
                ('user_cellNumber', models.CharField(max_length=10)),
                ('user_email', models.CharField(max_length=100)),
                ('user_password', models.CharField(max_length=30)),
            ],
        ),
    ]
